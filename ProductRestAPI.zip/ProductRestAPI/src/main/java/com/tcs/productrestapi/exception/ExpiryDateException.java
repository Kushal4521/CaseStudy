package com.tcs.productrestapi.exception;

public class ExpiryDateException extends Exception {

	public ExpiryDateException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
