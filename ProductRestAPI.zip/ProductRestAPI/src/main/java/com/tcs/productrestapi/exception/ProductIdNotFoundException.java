package com.tcs.productrestapi.exception;

public class ProductIdNotFoundException extends Exception {

	public ProductIdNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
